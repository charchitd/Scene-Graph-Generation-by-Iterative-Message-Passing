#!/bin/bash

python vg_to_imdb.py \
    --imh5_dir . \
    --image_size 1024 \
