# ROI Data Layers

This directory contains a set of data processing utilities adapted from py-faster-rcnn (https://github.com/rbgirshick/py-faster-rcnn).
