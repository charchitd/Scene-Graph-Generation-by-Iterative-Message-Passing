Scripts are under `experiments/scripts`.

Configuration override files used in the experiments are stored in `experiments/cfgs`.
